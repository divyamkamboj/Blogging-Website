import React from "react";

const NotFound = () => {
  return (
    <div>
      <img src="/images/404.jpg" alt="Page not found" />
    </div>
  );
};

export default NotFound;
